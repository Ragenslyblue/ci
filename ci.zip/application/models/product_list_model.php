<?php

class ProductList_Model extends CI_Model{
    var $errMsg="";
    public function __construct()
	{
	   parent::__construct();
	    
	}
    function retrieve_id(){
        $query_id= $this->db->get('productid_startpoint ');
        $row=$query_id->row();
        $start=$row->starting_point;
        
        $query_rows=$this->db->get('product');
        $num_rows=$query_rows->num_rows();
        $d=date('y');
        $prod_id=$d.($start+$num_rows);
        return $prod_id;
    }
    function retrieve_info(){
        $id_num=$this->input->post('txtProductId');
        $this->db->where('id_num', $id_num);
        $query_productinfo=$this->db->get('product');
    }
    function add_product_info(){
        $arr=array('item_id'=>$this->input->post('txtProductId'),
                    'item_name'=>$this->input->post('txtProductName'),
                    'material'=>$this->input->post('txtMaterials'),
                    'size'=>$this->input->post('txtSize'),
                    'color'=>$this->input->post('txtColor'),
                    'other_info'=>$this->input->post('txtOther'),
                    'image'=>$this->input->post('btnImage'),
                    'department_id'=>$this->input->post('lst_dept'),
                    'project_id'=>$this->input->post('lst_proj'),
                    'unit_price'=>$this->input->post('txtUnitPrice'),
                    'unit_used'=>$this->input->post('lst_unit'),
                    'product_code'=>$this->input->post('txtProductCode'),
                    'model'=>$this->input->post('txtModel'),
                    'serial'=>$this->input->post('txtSerialNum'),
                    'weight'=>$this->input->post('txtWeight'),
                    'length'=>$this->input->post('txtLength'),
                    'height'=>$this->input->post('txtHeight'),
                    'depth/width'=>$this->input->post('txtWidthDepth'),
                    'design'=>$this->input->post('txtDesign'),
                    'date'=>$this->input->post('txtWarranty'));
    }
}

?>