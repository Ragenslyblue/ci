<?php
class Settings_Model extends CI_Model{
    public function __construct()
	{
	   parent::__construct();
	    
	}
    function retrieve_dept()
    {
        $query_dept = $this->db->get('department');
        return $query_dept->result();
    }
    function insert_dept(){
        $arr = array('dept_name'=>$this->input->post('txtDepartment'));        
        $this->db->insert('department', $arr);   
    }
    function delete_dept(){
        $id_num = $this->input->post('lst_dept');
        $this->db->where('id_num', $id_num);
        $this->db->delete('department');
    }
    function retrieve_type(){
        $query_type = $this->db->get('payment_type');
        return $query_type->result();
    }
    function insert_type(){        
        $arr=array('payment_type'=> $this->input->post('txtPaymentTypes'));
        $this->db->insert('payment_type', $arr);
    }
    function delete_type(){
        $id_num2= $this->input->post('lst_type');
        $this->db->where('id_num', $id_num2);
        $this->db->delete('payment_type');
        $this->db->where('payment_type_id', $id_num2);
        $this->db->delete('payment_term');
    }
    function add_terms(){
        $arr=array('payment_type_id'=>$this->input->post('selType'),
                    'term'=> $this->input->post('txtTerms') ."-".$this->input->post('selTerm') );
        $this->db->insert('payment_term', $arr);
    }
    function delete_terms(){
        $id_num= $this->input->post('lst_tterms');
        $this->db->where('id_num', $id_num);
        $this->db->delete('payment_term');
    }
    function retrieve_terms(){
        $query_tterms = $this->db->get('payment_term');
        return $query_tterms->result();
    }
    function add_receipt(){
        $arr=array('receipt_type'=> $this->input->post('txtReceiptType'));
        $this->db->insert('receipt_type', $arr);
    }
    function delete_receipt(){
        $id_num= $this->input->post('lstReceiptType');
        $this->db->where('id_num', $id_num);
        $this->db->delete('receipt_type');
        $this->db->where('receipt_type_id', $id_num);
        $this->db->delete('receipt_series');
    }    
    function retrieve_receipt(){
        $query_receipt = $this->db->get('receipt_type');
        return $query_receipt->result();
    }
    function add_series(){
        $arr=array('receipt_type_id'=> $this->input->post('lstReceiptType'),
                    'series_num_from'=> $this->input->post('txtSeriesNumFrom'), 
                    'series_num_to'=> $this->input->post('txtSeriesNumTo'),
                    'in_use'=> $this->input->post('radUseReceipt'));
        $this->db->insert('receipt_series', $arr);
        
    }
    function delete_series(){
        $id_num= $this->input->post('lstReceiptSeries');
        $this->db->where('id_num', $id_num);
        $this->db->delete('receipt_series');
    }
    function retrieve_series(){
        $query_rseries = $this->db->get('receipt_series');
        return $query_rseries->result();
    }
    function custId_startPoint(){        
        $this->db->empty_table('customerid_startpoint');        
        $arr=array('starting_point'=> $this->input->post('txtCustId_start'));
        $this->db->insert('customerid_startpoint', $arr);
    }
    function projectId_startPoint(){        
        $this->db->empty_table('projectid_startpoint');        
        $arr=array('starting_point'=> $this->input->post('txtProjectId_start'));
        $this->db->insert('projectid_startpoint', $arr);
    }    
}
?>