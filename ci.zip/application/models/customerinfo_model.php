<?php
class Customerinfo_Model extends CI_Model
{
    var $errMsg = "";
    public function __construct()
    {
        parent::__construct();

    }

    function retrieve_id()
    {
        $query_id = $this->db->get('customerid_startpoint ');
        $row = $query_id->row();
        $start = $row->starting_point;

        $query_rows = $this->db->get('customer_info');
        $numrow = $query_rows->num_rows();
        $d = date('y');
        $curr_id = $d . ($start + $numrow);
        return $curr_id;

    }
    function retrieve_custinfo()
    {
        $id_num = $this->input->post('txtid');
        $this->db->where('id_num', $id_num);
        $query_custinfo = $this->db->get('customer_info');

        $num = $query_custinfo->num_rows();
        if ($num <= 0) {
            $errMsg = "Not Found!";
            return $errMsg;
        } else {
            return $query_custinfo->result();

            $query_custSpouse = $this->db->get('customer_spouse');
            return $query_custSpouse->result();
        }
    }
    function add_custinfo()
    {
        $arr = array(
            'customer_id' => $this->input->post('txtid'),
            'last_n' => $this->input->post('txtlast'),
            'first_n' => $this->input->post('txtfirst'),
            'middle_n' => $this->input->post('txtmiddle'),
            'age' => $this->input->post('txtage'),
            'sex' => $this->input->post('radbtnGender'),
            'civil_status' => $this->input->post('radBtnStatus'),
            'present_address' => $this->input->post('txtPresentAdd'),
            'residential_status' => $this->input->post('radbtnResStat'),
            'permanent_address' => $this->input->post('txtpermanent'),
            'contact_home' => $this->input->post('txtContactHome'),
            'contact_office' => $this->input->post('txtContactOffice'),
            'cellphone' => $this->input->post('txtContactCell'),
            'email' => $this->input->post('txtEmail'),
            'source_income' => $this->input->post('radbtnIncome'),
            'company_name' => $this->input->post('txtCompany'),
            'company_address' => $this->input->post('txtCompanyAdd'),
            'position' => $this->input->post('txtPosition'),
            'mo_income' => $this->input->post('txtIncome'),
            'employment_status' => $this->input->post('radbtnEmpStat'),
            'image_url' => $this->input->post('fileImage'),
            'sketch_url' => $this->input->post('fileSketch'),
            'length_residence_mos' => $this->input->post('txtLenResidence'));

        $new = $this->db->insert('customer_info', $arr);

        $row = $this->db->get('customer_info');
        $lastRowID = $row->last_row();

        //***** lacking file upload **********

        $config['upload_path'] = 'uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        //$config['max_size']	= '100';
        //$config['max_width']  = '1024';
        //$config['max_height']  = '768';

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('fileImage')) {
            echo "upload sucessful";
            die();

            $data = array('upload_data' => $this->upload->data());

            //$this->load->view('upload_form', $error);
        } else {
            echo "err";
        }


        if ($this->input->post('radBtnStatus') != 0) {
            $arr = array(
                'customer_info_id' => $lastRowID->customer_id,
                'spouse_name' => $this->input->post('txtSpouse'),
                'age' => $this->input->post('txtSpouseAge'),
                'contact' => $this->input->post('txtSpouseContact'),
                'source_income' => $this->input->post('radbtnSpouseIncome'),
                'company_name' => $this->input->post('txtSpouseCompany'),
                'company_address' => $this->input->post('txtSpouseCompanyAdd'),
                'mo_income' => $this->input->post('txtSpouseIncome'),
                'employment_status' => $this->input->post('radbtnSpouseEmpStat'),
                'number_children' => $this->input->post('txtNumChild'),
                'child1' => $this->input->post('txtChild1'),
                'child2' => $this->input->post('txtChild2'),
                'child3' => $this->input->post('txtChild3'),
                'educ1' => $this->input->post('txtEduc1'),
                'educ2' => $this->input->post('txtEduc2'),
                'educ3' => $this->input->post('txtEduc3'),
                'position' => $this->input->post('txtSpousePosition'),
                );
            $this->db->insert('customer_spouse', $arr);
        }
    }


}
?>