<?php
class Project_list_Model extends CI_Model{
    var $project_id="";
    var $project_name="";
    var $department="";
    var $in_charge="";
    var $status="";
    var $customer="";
    var $company="";
    var $payment_status="";
    var $assigned_employee="";
    var $polisher="";
    
    
    public function __construct()
	{
	   parent::__construct();
	}
    function retrieve_id(){
       $query_id= $this->db->get('projectid_startpoint ');
       $row=$query_id->row();
       $start= $row->starting_point;
       
       $query_rows= $this->db->get('project_list');
       $numrow=$query_rows->num_rows();
       $d=date('y');
       $curr_projid= $d.($start+$numrow);
       return $curr_projid;
                    
    }
    
    function retrieve_project(){
        $query_project=$this->db->get('project_details');
        return $query_project->result();
    }
    function insert_project(){
        $arr= array(
                'project_id'=>$this->input->post('txtProjectId'),
                'project_name'=>$this->input->post('txtProjectName'),
                'amount'=>$this->input->post('txtContractAmount'),
                'private_govt'=>$this->input->post('radbtnPrivate'),
                'payment_details'=>$this->input->post('txtPayment_details'),
                'polisher'=>$this->input->post('txtPolisher'),
                'warranty'=>$this->input->post('txtWarranty'),
                'supplier'=>$this->input->post('txtSupplier'),
                'project_id'=>$this->input->post('txtProjectId'),
                'project_id'=>$this->input->post('txtProjectId'),
                'project_id'=>$this->input->post('txtProjectId'),
                'project_id'=>$this->input->post('txtProjectId'),
                'project_id'=>$this->input->post('txtProjectId'),
                'project_id'=>$this->input->post('txtProjectId'),
                'project_id'=>$this->input->post('txtProjectId'),
                'project_id'=>$this->input->post('txtProjectId'),
                
                );
        $this->db->insert('project_details', $array);
    }
    function retrieve_project_name(){
        $query_project_name=$this->db->get('project_list');
        return $query_project_name->result();
    }
    function insert_project_name(){
        $array2=array('project_name'=>$this->input->post('txtProjectName'));
        $this->db->insert('project_list', $array2);
    }
    function retrieve_dept()
    {
        $query_dept = $this->db->get('department');
        return $query_dept->result();
    }
    function delete_dept(){
        $id_num= $this->input->post('lst_dept');
        $this->db->where('id_num', $id_num);
        $this->db->delete('department');
        
    }
    function retrieve_employee(){
        $query_employee=$this->db->get('employee');
        return $query_employee->result();
    }
    function insert_incharge(){
        $array3=array('	employee_id'=>$this->input->post('txtInCharge'));
        $this->db->insert('employee', $array2);
    }
    function retrieve_status(){
        $query_status=$this->db->get('employee');
        return $query_status->result();
    }
    function insert_status(){
        $arrayStatus=array('marital_stat'=>$this->input->post('txtStatus'));
        $this->db->insert('employee', $arrayStatus);
    }
    function retrieve_customer(){
        $query_custname=$this->db->get('customer_info');
        return $query_custname->result();
    }
    function delete_customer(){
        $id_num_cust=$this->input->post('lst_customer');
        $this->db->where('id_num', $id_num_cust);
        $this->db->delete('customer_info');
    }
    function retrieve_company(){
        $query_comp=$this->db->get('customer_info');
        return $query_comp->result();
    }
    function delete_company(){
        $id_num_comp=$this->input->post('lst_company');
        $this->db->where('id_num', $id_num_comp);
        $this->db->delete('customer_spouse');
    }
    function retrieve_payment_status(){
        $query_payment=$this->db->get('project_list');
        return $query_payment->result();
    }
    function insert_payment_status(){
        $arrayPayment=array('payment_stats'=>$this->input->post('txtPayment_status'));
        $this->db->insert('project', $arrayPayment);
    }
    function retrieve_assigned(){
        $query_assigned=$this->db->get('employee');
        return $query_assigned->result();
    }
    function delete_assigned(){
        $id_num_assigned=$this->input->post('lst_assigned');
        $this->db->where('id_num', $id_num_assigned);
        $this->db->delete('employee');
    }
    function retrieve_polisher(){
        $query_polisher=$this->db->get('project_list');
        return $query_polisher->result();
    }
    function insert_polisher(){
        $arrayPolisher=array('polisher/finisher'=>$this->input->post('txtPolisher'));
        $this->db->insert('project_list', $arrayPolisher);
    }
    function retrieve_delivery(){
        $query_deliver=$this->db->get('project_list');
        return $query_deliver->result();
    }
    function insert_delivery(){
        $arrayDelivery=array('delivery'=>$this->input->post('txtDeliver'));
        $this->db->insert('project_list', $arrayDelivery);
    }
    function retrieve_contract(){
        $query_contract=$this->db->get('project_list');
        return $query_contract->result();
    }
    function insert_contract(){
        $arrayContract=array('contract_amount'=>$this->input->post('txtContactAmount'));
        $this->db->insert('project_list', $arrayContract);
    }
    function retrieve_deli_sched(){
        $query_deli_sched=$this->db->get('project_list');
        return $query_deli_sched->result();
    }
    function insert_deli_sched(){
        $arrayDeliSched=array('date'=>$this->input->post('txtDeliverySched'));
        $this->db->insert('project_list', $arrayDeliSched);
    }
    function retrieve_warranty(){
        $query_warranty=$this->db->get('project_list');
        return $query_warranty->result();
    }
    function insert_warranty(){
        $arrayWarranty=array('warranty'=>$this->input->post('txtWarranty'));
        $this->db->insert('project_list', $arrayWarranty);
    }
    function retrieve_supplier(){
        $query_supplier=$this->db->get('project_list');
        return $query_supplier->result();
    }
    function insert_supplier(){
        $arraySupplier=array('supplier'=>$this->input->post('txtSupplier'));
        $this->db->insert('project_list', $arraySupplier);
    }
    function retrieve_attachments(){
        $query_attachments=$this->db->get('employee');
        return $query_attachments->result();
    }
    function insert_attachments(){
        $arrayAttachments=array('attachment1'=>$this->input->post('txtAttachments'));
        $arrayAttachments2=array('attachment2'=>$this->input->post('txtAttachments'));
        $this->db->insert('project_list', $arrayAttachments, $arrayAttachments2);
    }
}
?>