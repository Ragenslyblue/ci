<?php
class Project_list_Controller extends CI_Controller{
    function __construct() {
    parent::__construct();
    $this->load->helper(array('form', 'url'));
    $this->load->library('form_validation');
    }
    
    function index(){
        $this->load->model('Project_list_Model');
        $data['curr_projid'] = $this->Project_list_Model->retrieve_id();
        $data['query_project'] = $this->Project_list_Model->retrieve_project();        
        $data['query_project_name']= $this->Project_list_Model->retrieve_project_name();        
        $data['query_dept']= $this->Project_list_Model->retrieve_dept();
        $data['query_employee']= $this->Project_list_Model->retrieve_employee();
        $data['query_status']= $this->Project_list_Model->retrieve_status();
        $data['query_custname']= $this->Project_list_Model->retrieve_customer();
        $data['query_comp']= $this->Project_list_Model->retrieve_company();
        $data['query_payment']= $this->Project_list_Model->retrieve_payment_status();
        $data['query_assigned']= $this->Project_list_Model->retrieve_assigned();
        $data['query_polisher']= $this->Project_list_Model->retrieve_polisher();
        $data['query_deliver']= $this->Project_list_Model->retrieve_delivery();
        $data['query_contract']= $this->Project_list_Model->retrieve_contract();
        $data['query_deli_sched']= $this->Project_list_Model->retrieve_deli_sched();
        $data['query_warranty']= $this->Project_list_Model->retrieve_warranty();
        $data['query_supplier']= $this->Project_list_Model->retrieve_supplier();
        $data['query_attachments']= $this->Project_list_Model->retrieve_attachments();
        
                  
        $this->load->view('header');
        $this->load->view('project_list', $data);
        $this->load->view('footer');

        }
        
        function insert_project(){
        //$this->form_validation->set_rules('txtProjectId', 'project details', 'required');
        
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_project();
            $this->index();
       }
    }
     function insert_project_name(){
        $this->form_validation->set_rules('txtProjectName', 'project_name', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_project_name();
            $this->index();
       }
    }
    function delete_dept(){
       $this->load->model('Project_list_Model');
       $this->Project_list_Model->delete_dept();
       $this->index();
    }
    function insert_incharge(){
        $this->form_validation->set_rules('txtInCharge', 'Employee', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_incharge();
            $this->index();
       }
    }
    function insert_status(){
        $this->form_validation->set_rules('txtStatus', 'marital status', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_status();
            $this->index();
       }
    }
    function delete_customer(){
       $this->load->model('Project_list_Model');
       $this->Project_list_Model->delete_customer();
       $this->index();
    }
    function delete_company(){
       $this->load->model('Project_list_Model');
       $this->Project_list_Model->delete_company();
       $this->index();
    }
    function insert_payment_status(){
        $this->form_validation->set_rules('txtPayment_status', 'payment status', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_payment_status();
            $this->index();
       }
    }
    function delete_assigned(){
       $this->load->model('Project_list_Model');
       $this->Project_list_Model->delete_assigned();
       $this->index();
    }
    function insert_polisher(){
        $this->form_validation->set_rules('txtPolisher', 'Polisher', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_polisher();
            $this->index();
       }
    }
    function insert_delivery(){
        $this->form_validation->set_rules('txtDeliver', 'Delivery', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_delivery();
            $this->index();
       }
    }
    function insert_contract(){
        $this->form_validation->set_rules('txtContactAmount', 'Contract amount', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_contract();
            $this->index();
       }
    }
    function insert_deli_sched(){
        $this->form_validation->set_rules('txtDeliverySched', 'Date', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_deli_sched();
            $this->index();
       }
    }
    function insert_warranty(){
        $this->form_validation->set_rules('txtWarranty', 'Warranty', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_warranty();
            $this->index();
       }
    }
    function insert_supplier(){
        $this->form_validation->set_rules('txtSupplier', 'Supplier', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_supplier();
            $this->index();
       }
    }
    function insert_attachments(){
        $this->form_validation->set_rules('txtAttachments', 'Attachments', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Project_list_Model');
            $this->Project_list_Model->insert_attachments();
            $this->index();
       }
    }
}
?>