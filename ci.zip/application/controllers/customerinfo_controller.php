<?php
class Customerinfo_Controller extends CI_Controller{
    var $errMsg="";
    
    function __construct() {
    parent::__construct();
    $this->load->helper(array('form', 'url'));
    $this->load->library('form_validation');    
    }
    function index(){
        
        $this->load->model('Customerinfo_Model');
        $data['curr_id'] = $this->Customerinfo_Model->retrieve_id();
        $data['query_custinfo'] = $this->Customerinfo_Model->retrieve_custinfo();  
        
        $data['errMsg']="";
        
                
        $this->load->view('header');
        $this->load->view('customer_info', $data);
        $this->load->view('footer');
    }
    function add_custinfo(){
            $this->load->model('Customerinfo_Model');
            $this->Customerinfo_Model->add_custinfo();
            $this->index();
    }
    function processInfo(){ 
       /* 
        $this->form_validation->set_rules('txtlast', 'Last Name', 'required|alpha');
        $this->form_validation->set_rules('txtfirst', 'First Name', 'required|alpha');
        $this->form_validation->set_rules('txtmiddle', 'Middle Name', 'alpha');
        $this->form_validation->set_rules('txtage', 'Age', 'numeric');
        $this->form_validation->set_rules('radbtnGender', 'Gender', 'required');
        $this->form_validation->set_rules('radBtnStatus', 'Civil Status', 'required');
        $this->form_validation->set_rules('txtPresentAdd', 'Present Address', 'required');
        $this->form_validation->set_rules('txtLenResidence', 'Length of Residence', 'numeric');
        $this->form_validation->set_rules('txtEmail', 'Email Address', 'valid_email');
        $this->form_validation->set_rules('radbtnIncome', 'Source of Income', 'required');
        
        if($this->input->post('radBtnStatus') != 0){
        $this->form_validation->set_rules('txtSpouse', 'Spouse Name', 'required|alpha');
        $this->form_validation->set_rules('txtSpouseAge', 'Age of Spouse', 'numeric');
        $this->form_validation->set_rules('txtNumChild', 'Number of Children', 'numeric');
        }
        
        */
        if($this->form_validation->run() == false){
        $this->index();
        }else{    
        
            if(isset($_POST['btnSave'])){
                $this->add_custinfo();        
            }
            if(isset($_POST['btnView'])){
                $this->retrieve_custinfo();        
            }
       }        
    }
    
    function retrieve_custinfo(){
        $this->load->model('Customerinfo_Model');
        $this->Customerinfo_Model->retrieve_custinfo();
        $this->index();
    }
    
}
?>