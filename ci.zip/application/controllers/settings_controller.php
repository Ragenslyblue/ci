<?php
class Settings_Controller extends CI_Controller{
    function __construct() {
    parent::__construct();
    $this->load->helper(array('form', 'url'));
    $this->load->library('form_validation');
    }
    
    function index(){
        
        $this->load->model('Settings_Model');
        $data['query_dept'] = $this->Settings_Model->retrieve_dept();        
        $data['query_type']= $this->Settings_Model->retrieve_type();        
        $data['query_terms']= $this->Settings_Model->retrieve_terms();
        $data['query_receipt']= $this->Settings_Model->retrieve_receipt();
        $data['query_rseries']= $this->Settings_Model->retrieve_series();
                
        $this->load->view('header');
        $this->load->view('settings', $data);
        $this->load->view('footer');
    }
  
    function insert_dept(){
        $this->form_validation->set_rules('txtDepartment', 'Department', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
            $this->load->model('Settings_Model');
            $this->Settings_Model->insert_dept();
            $this->index();
       }
    }
    
    function delete_dept(){
       $this->load->model('Settings_Model');
       $this->Settings_Model->delete_dept();
       $this->index();
    }
    
    
    function insert_type(){
       $this->form_validation->set_rules('txtPaymentTypes', 'Payment Type', 'required');
       if ($this->form_validation->run() == false){
        $this->index();
       }else{
       $this->load->model('Settings_Model');
       $this->Settings_Model->insert_type();
       $this->index();
       }
    }
    function delete_type(){
       $this->load->model('Settings_Model');
       $this->Settings_Model->delete_type();
       $this->index();
    }
    
    function add_terms(){
        $this->form_validation->set_rules('txtTerms', 'Payment Terms', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{    
        $this->load->model('Settings_Model');
        $this->Settings_Model->add_terms();
        $this->index();
        }        
    }
    function delete_terms(){
        $this->load->model('Settings_Model');
        $this->Settings_Model->delete_terms();
        $this->index();
    }
    function add_receipt(){
        $this->form_validation->set_rules('txtReceiptType', 'Receipt Type', 'required');
        if ($this->form_validation->run() == false){
        $this->index();
        }else{
        $this->load->model('Settings_Model');
        $this->Settings_Model->add_receipt();
        
        $this->index();
        }        
    }
    function delReceipt_addDelSeries(){
        if(isset($_POST['btnAddSeries'])){
            $this->form_validation->set_rules('txtSeriesNumFrom', 'Series From" ', 'required|numeric');
            $this->form_validation->set_rules('txtSeriesNumTo', 'Series To" ', 'required|numeric');
            if ($this->form_validation->run() == false){
            $this->index();
            }else{
                $this->load->model('Settings_Model');
                $this->Settings_Model->add_series();
                $this->index();
            }
        }else{       
        
            $this->load->model('Settings_Model');
            
            if(isset($_POST['btnDeleteReceiptType'])){
                $this->Settings_Model->delete_receipt();
            }
            
            if(isset($_POST['btnDeleteSeries'])){
                $this->Settings_Model->delete_series();
            }
            $this->index();
        }
        
    }
    function custId_startPoint(){
        $this->form_validation->set_rules('txtCustId_start', 'Customer ID Starting Point" ', 'required|numeric');
        if ($this->form_validation->run() == false){
            $this->index();
        }else{
                $this->load->model('Settings_Model');
                $this->Settings_Model->custId_startPoint();
                $this->index();
            }
    }
    function projectId_startPoint(){
        $this->form_validation->set_rules('txtProjectId_start', 'Project ID Starting Point" ', 'required|numeric');
        if ($this->form_validation->run() == false){
            $this->index();
        }else{
                $this->load->model('Settings_Model');
                $this->Settings_Model->projectId_startPoint();
                $this->index();
            }
    }
}
?>