<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {
    
	public function index()
	{  
	        
	   $this->load->view('header');
        $this->load->view('body');
        $this->load->view('footer');
    }
    public function project_list()
	{  
	   $data['title']='project_list';
       
       $this->load->view('header');
        $this->load->view('project_list', $data);
        $this->load->view('footer');
    }
    public function customer_info()
	{  
	   $data['title']='customer_info';
       
	   $this->load->view('header');
        $this->load->view('customer_info', $data);
        $this->load->view('footer');
    }
    public function customer_account()
	{  
	   $data['title']='customer_account';
	   
	   $this->load->view('header');
        $this->load->view('customer_account', $data);
        $this->load->view('footer');
    }
    public function product_list()
	{  
	   $data['title']='product_list';
       
	   $this->load->view('header');
        $this->load->view('product_list', $data);
        $this->load->view('footer');
    }
    
    
}
    
    

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */