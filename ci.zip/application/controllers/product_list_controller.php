<?php

class ProductList_Controller extends CI_Controller{
    var $errMsg="";
    
    function __construct() {
    parent::__construct();
    $this->load->helper(array('form', 'url'));
    $this->load->library('form_validation');
    }
    function index(){
        
        $this->load->model('ProductList_Model');
        $data['prod_id']=$this->ProductList_Model->retrieve_id();
        $data['query_productinfo']=$this->ProductList_Model->retrieve_info();
        
        $data['errMsg']="";
        
        $this->load->view('header');
        $this->load->view('product_list', $data);
        $this->load->view('footer');
    }   
    function add_product_info(){
        $this->load->model('ProductList_Model');
        $this->ProductList_Model->add_product_info();
        $this->index();
    }
}

?>