<html>
<head>
	<meta charset="utf-8"/>
	<title><?= $title ?></title>
    
    <link rel="stylesheet" type="text/css" href="styles/stylesheet.css" /> 
</head>

<body>
<ul class="navigation">
	<?php foreach($nav_list  as $i => $nav_item): ?>
		<li class="<?= ($nav == $nav_item ? 'selected' : '')?>">
			<?= anchor($nav_item, $nav_item) ?>
		</li>
	<?php endforeach ?>
</ul>
    <div id="contents"><?= $contents ?></div>
    
</body>
</html>