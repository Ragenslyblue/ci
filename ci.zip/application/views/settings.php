<?php $this->load->helper('form');
$this->load->library('form_validation'); 
echo "<span class='errmsg'>".validation_errors()."</span>";
?>
<div class="divTable">           
Settings
<div class="divRow">
<div class="divColumn">
    Departments:
    </div>
<?php   
echo form_open('Settings_Controller/insert_dept');
?>

    <div class="divColumn">
    <input type="text" name="txtDepartment" id="txtDepartment" 
         value="<?php if(validation_errors()) echo set_value('txtDepartment'); ?>"   />
    </div>
    <div class="divColumn">
    <input type="submit" name="btnAddDept" id="btnAddDept" value="Add" />
    </div>
<?php echo form_close(); 
echo form_open('settings_controller/delete_dept'); 
?>

    <div class="divColumn">
    <input type="submit" name="btnRemoveDept" value="Remove" />
    </div>


    <div class="divColumn">
    <select name="lst_dept" multiple>
    <?php foreach($query_dept as $dept){ ?>
        <option value="<?php echo $dept->id_num; ?>"><?php echo $dept->dept_name; ?></option>
    <?php } ?>
    </select>
 </div>
 <br />
 <br />
 <hr />
 <br />
 <div></div>
 
</div>
<?php echo form_close(); 
echo form_open('Settings_Controller/insert_type'); 
?>

<div class="divRow">
    <div class="divColumn">Payment Types:</div>
    <div class="divColumn">
    <input type="text" name="txtPaymentTypes" id="txtPaymentTypes" 
        value="<?php if(validation_errors()) echo set_value('txtPaymentTypes'); ?>" />
    </div>
    <div class="divColumn">
    <input type="submit" name="btnAddType" value="Add Type" />
    </div>
</div>
<?php echo form_close(); 
echo form_open('settings_controller/delete_type'); 
?>
    <div class="divColumn">
    <input type="submit" name="btnRemoveType" value="Remove" />
    </div>
    <div class="divColumn">
     <select name="lst_type" multiple="multiple">
     <?php foreach($query_type as $type){ ?>
        <option value="<?php echo $type->id_num; ?>"><?php echo $type->payment_type; ?></option>
        
    <?php } ?>
 </select>
    </div>
    
<?php echo form_close(); 
echo form_open('settings_controller/add_terms');?>

<div class="divRow">
    <div class="divColumn">
        <select id="selType" name="selType">
            <option value="0">Select Type ...</option>
            <?php foreach($query_type as $type){ ?>
            <option value="<?php echo $type->id_num; ?>"><?php echo $type->payment_type; ?></option>
            <?php } ?>
        </select>
    </div>
    <div class="divColumn">
    <input type="text" name="txtTerms" id="txtTerms"
        value="<?php if(validation_errors()) echo set_value('txtTerms'); ?>" />
    </div>
    <div class="divColumn">
        <select id="selTerm" name="selTerm">
            <option value="0">Select Terms ...</option>
            <option value="months">Months</option>
            <option value="days">Days</option>
        </select>
    </div>
    <div class="divColumn">
    <input type="submit" name="btnAddTerms" id="btnAddTerms" value="Add"/>
    </div>
</div>
<?php echo form_close();
 echo form_open('settings_controller/delete_terms'); ?>
<div class="divRow">
    <div class="divColumn">&nbsp;</div>
    <div class="divColumn">
        <select id="lst_tterms" name="lst_tterms" multiple="multiple">
            <?php 
            foreach($query_type as $type){ 
                foreach($query_terms as $tterms){ 
                    if($type->id_num == $tterms->payment_type_id){?>
            <option value="<?php echo $tterms->id_num; ?>"><?php echo $type->payment_type ." = " .$tterms->term; ?></option>
            <?php   } 
                }
            } ?>            
        </select>
    </div>
    <div class="divColumn">&nbsp;</div>
    <div class="divColumn">
        <input type="submit" name="btnRemoveTerms" id="btnRemoveTerms" value="Remove" />
    </div>
</div>
<?php echo form_close(); ?>
<div class="divRow">
Receipt Series    
</div>
<?php echo form_open('settings_controller/add_receipt'); ?>

<div class="divRow">
    <div class="divColumn">Receipt Type:</div>
    <div class="divColumn"><input type="text" name="txtReceiptType" id="txtReceiptType" 
        value="<?php if(validation_errors()) echo set_value('txtReceiptType'); ?>" />
    </div>    
    <div class="divColumn">
        <input type="submit" id="btnAddReceiptType"  name="btnAddReceiptType" value="Add" />
    </div>
</div>
<?php echo form_close(); 
echo form_open('settings_controller/delReceipt_addDelSeries'); ?>
<div class="divRow">
    <div class="divColumn">Enter Series of Type:</div>
    <div class="divColumn">
    <select name="lstReceiptType" id="lstReceiptType" >
        <?php foreach($query_receipt as $rtype){ ?>
        <option value="<?php echo $rtype->id_num; ?>"><?php echo $rtype->receipt_type; ?></option>        
        <?php } ?>  
    </select>
    </div>
    <div class="divColumn">
        <input type="submit" id="btnDeleteReceiptType"  name="btnDeleteReceiptType" value="Delete" />
    </div>
</div>
 
<div class="divRow">
    <div class="divColumn">
    From:
    </div>
    <div class="divColumn">
        <input type="text" name="txtSeriesNumFrom" id="txtSeriesNumFrom" 
                value="<?php if(validation_errors()) echo set_value('txtSeriesNumFrom'); ?>"  />
    </div>
    <div class="divColumn">
    To:
    <input type="text" name="txtSeriesNumTo" id="txtSeriesNumTo" 
            value="<?php if(validation_errors()) echo set_value('txtSeriesNumTo'); ?>"/>
    </div>
</div>

<div class="divRow">
    <div class="divColumn">Pages per Book:</div>
    <div class="divColumn">
        <input type="text" name="txtPageBook" />
    </div>
    <div class="divColumn">In Use?
        <input type="radio" name="radUseReceipt" id="radUseReceipt" value="1" />YES
        <input type="radio" name="radUseReceipt" id="radUseReceipt" value="0" checked="" />NO
    </div>
</div>
<div class="divRow">
    <div class="divColumn"> &nbsp;  </div>
    <div class="divColumn"> 
        <select name="lstReceiptSeries" id="lstReceiptSeries" multiple="">
            <?php 
            foreach($query_receipt as $rtype){ 
                foreach($query_rseries as $rseries){ 
                    if($rtype->id_num == $rseries->receipt_type_id){
                        $stat='Reserved';
                        if($rseries->in_use==1){ $stat="In Use";}?>
                    <option value="<?php echo $rseries->id_num; ?>">
                    <?php echo $rtype->receipt_type .
                                " => Series #: " . $rseries->series_num_from .
                                "-".$rseries->series_num_to ."   *** ". $stat; ?>
                    </option>
            <?php   } 
                }
            } ?>
        </select>  
    </div>
</div>
<div class="divRow">
    <div class="divColumn"> &nbsp;  </div>    
    <div class="divColumn">
    <input type="submit" name="btnAddSeries" value="Add" />
    <input type="submit" name="btnDeleteSeries" value="Delete" />
    <?php echo form_close();  ?>
    </div>
</div>
<?php echo form_open('settings_controller/custId_startPoint'); ?>
<div class="divRow">
    <div class="divColumn">Customer ID Starting point</div>
    <div class="divColumn50">
    <input type="text"  
        value="<?php echo date('y'); ?>" />
    <input type="text" name="txtCustId_start" id="txtCustId_start" 
        value="<?php if(validation_errors()) echo set_value('txtCustId_start'); ?>" />
    <input type="submit" value="Save" />
    </div>
</div>
<?php echo form_close();  ?>
<hr />
<?php echo form_open('settings_controller/projectId_startPoint'); ?>
<div class="divRow">
    <div class="divColumn">Project ID Starting point</div>
    <div class="divColumn50">
    <input type="text"  
        value="<?php echo date('y'); ?>" />
    <input type="text" name="txtProjectId_start" id="txtProjectId_start" 
        value="<?php if(validation_errors()) echo set_value('txtProjectId_start'); ?>" />
    <input type="submit" value="Save" />
    </div>
</div>
<?php echo form_close();  ?>

</div>