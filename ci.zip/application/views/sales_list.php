Sales List<br />
<div class="containerDiv">

  <div class="rowDivHeader">
    <div class="cellDivHeader">Department</div>
    <div class="cellDivHeader">#</div>
    <div class="cellDivHeader">Customer Name</div>
    <div class="cellDivHeader">Unit Type</div>
    <div class="cellDivHeader">Quality</div>
    <div class="cellDivHeader">Project</div>
    <div class="cellDivHeader lastCell">Cash Sales</div>
    <div class="cellDivHeader lastCell">DIP</div>
    <div class="cellDivHeader lastCell">Collection</div>
    <div class="cellDivHeader lastCell">Lay-Away</div>
    <div class="cellDivHeader lastCell">A/R</div>
  </div>

  <div class="rowDiv">
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv lastCell"></div>
  </div>
</div>