<!DOCTYPE HTML>
<html>
<head>
<title>Gallega Marketing</title>
<link href="<?php echo base_url('styles/stylesheet.css'); ?>" rel="stylesheet" />


</head>
<body>
<div id="container">
<?php $this->load->helper('url'); ?>
<h1><a href="<?php echo base_url(); ?>" title="Gallega Marketing">Gallega Marketing</a></h1>
<div id="nav">
<ul>
<li><?php echo anchor('settings_controller/index','Settings', "title='Settings'"); ?></li>
<li><?php echo anchor('project_list_controller/index','Project List',"title='Project Listing'"); ?></li>
<li><?php echo anchor('product_list_controller/index','Product Listing',"title='Product Listing'"); ?></li>
<li><?php echo anchor('customerinfo_controller/index','Customer Information',"title='Customer Information'"); ?></li>
<li><?php echo anchor('main/customer_account','Customer Account',"title='Customer Account'"); ?></li>
</ul>
</div>

<script type="text/javascript" src="<?php echo base_url('assets/js/knockout-3.3.0')?>"></script>