<!--<form action="" method="post" name="form_receipt" enctype='multipart/form-data' >-->
<div class="divTable">
RECEIPT:
<div class="divRow">
<div class="divColumn">Date:</div>
</div>
<div>
<div><input type="text" name="txtDate" id="txtDate" class="txtDate" /></div> 
</div>                             
<div>
<div>Time:</div>
</div>
<div>
<div><input type="text" name="txtTime" id="txtTime" class="txtTime" /></div>
</div>
<div>                
<div>Customer ID:</div>
</div>
<div>
<div><input type="text" name="txtCustomerid" id="txtCustomerid" class="txtCustomerid" /></div>
</div>
<div>
<div>Account id:</div>
</div>
<div>
<div><input type="text" name="txtAccountid" id="txtAccountid" class="txtAccountid" /></div>
</div>
<div>
<div>Customer's Name:</div>
</div>
<div>
<div><select>                                                                            
                    <option value="John"></option>                                                  
                    <option value="Doe"></option>                                                   
                    <option value="Wan"></option>
                    </select></div>
</div>

<div>
<div><input type="button" name="btnAdd" id="btnAdd" class="btnAdd" value="Add" /><input type="button" name="btnSearch3" id="btnSearch3" class="btnSearch3" value="Search" /></div>                                   
</div>     

<div>                    
<div>Quantity:</div>
</div>
<div>
<div><input type="text" name="txtQuality" id="txtQuality" class="txtQuality" /></div>
</div>
<div>
<div>Receipt Number:</div>
</div>
<div>
<div><select>
                    <option value="1"></option>
                    <option value="2"></option>
                    <option value="3"></option>
                    </select></div>
</div>
<div>
<div><input type="text" name="txtReceiptNum" id="txtReceiptNum" class="txtReceiptNum" /></div>
</div>
<div>
<div>Gross Sales:</div>
</div>
<div>
<div><input type="text" name="txtGrossSales" id="txtGrossSales" class="txtGrossSales" /></div>
</div>
<div>
<div>Payment Type:</div>
</div>
<div>
<div><select>
                    <option value="OR"></option>
                    <option value="DR"></option>
                    <option value="CR"></option>
                    </select></div>
</div>
<div>
<div><input type="text" name="txtPaymentType" id="txtPaymentType" class="txtPaymentType" /></div>
</div>
<div>
<div>Month</div>
</div>

<div>
<div>LESS: VAT:</div>
</div>
<div>
<div><input type="text" name="txtVat" id="txtVat" class="txtVat" /></div>
</div>
<div>
<div>Discount(Regular):</div>
</div>
<div>
<div><input type="text" name="txtDiscount" id="txtDiscount" class="txtDiscount" /></div>
</div>
        Rebate:<input type="text" name="txtRebate" id="txtRebate" class="txtRebate" /><br /><br />
        Discount(Senior/Pwd):<input type="text" name="txtDiscountSenior" id="txtDiscountSenior" class="txtDiscountSenior" /><br /><br />
        Net Sales:<input type="text" name="txtNetSales" id="txtNetSales" class="txtNetSales" /><br /><br />
<input type="button" name="btnAddAttachment" id="btnAddAttachment" class="btnAddAttachment" value="Add attachment" /><br /><br />
<input type="button" name="btnSave" id="btnSave" class="btnSave" value="Save" /><br /><br />
<input type="button" name="btnNew" id="btnNew" class="btnNew" value="New" /><br /><br />
<input type="button" name="btnEdit" id="btnEdit" class="btnEdit" value="Delete" /><br /><br />

<div id="div1">
<div>#</div>
<div><input type="checkbox" name="ck1" value="option1" /></div>
<div><input type="checkbox" name="ck2" value="option2" /></div>
</div><br /><br />

<div id="div2">
<div>Quality</div>
<div><select>
                    <option value="OR1"></option>
                    <option value="DR2"></option>
                    <option value="CR3"></option>
                    </select></div>
</div><br /><br />

<div id="div3">
<div>Unit</div>
<div><select>
                    <option value="O"></option>
                    <option value="D"></option>
                    <option value="C"></option>
                    </select></div>
</div><br /><br />

<div id="div4">
<div>Unit type</div>
<div><select>
                    <option value="O1"></option>
                    <option value="D2"></option>
                    <option value="C3"></option>
                    </select></div>
<div><input type="button" name="btnAdd2" class="btnAdd2" value="Add"  /></div>
<div><input type="button" name="btnSearch2" class="btnSearch2" value="Search"  /></div>                    
</div><br /><br />

<div id="div5">
<div>Unit Price</div>
<div><input type="text" name="txtUnitPrice" class="txtUnitPrice" /></div>
</div><br /><br />

<div id="div6">
<div>Total</div>
<div><input type="text" name="txtTotal" class="txtTotal" /></div>
</div><br /><br />

<div id="div7">
<div>Project Name</div>
<div><select>
                    <option value="O11"></option>
                    <option value="D22"></option>
                    <option value="C33"></option>
                    </select></div>
<div><input type="button" name="btnAdd5" class="btnAdd5" value="Add" /></div>
<div><input type="button" name="btnSearch5" class="btnSearch5" value="Search" /></div>
</div><br /><br />
</div>

<div id="div8">
<div><input type="button" name="btnAdd7" class="btnAdd7" /></div>
<div><input type="button" name="btnSearch7" class="btnSearch7" /></div>
</div><br /><br />

<input type="button" name="btnAddUnit" class="btnAddUnit" value="Add Unit" /><br /><br />
<input type="button" name="btnEdit4" class="btnEdit4" value="edit" /><br /><br />
<input type="button" name="btnDelete" class="btnDelete" value="Delete" /><br /><br />
<!--</form>-->
</div>