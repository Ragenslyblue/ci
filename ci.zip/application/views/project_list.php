<?php $this->load->helper('form');
$this->load->library('form_validation'); 
echo "<span class='errmsg'>" . validation_errors() . "</span>"; 
echo form_open('Project_list_Controller/insert_project'); 
?>

Project List
<div class="divTable">
<div class="divRow">
    <div class="divColumn">Project ID:</div>
    <div class="divColumn">
    <input type="text" name="txtProjectId" id="txtProjectId" 
    value="<?php echo $curr_projid; if(validation_errors()) echo set_value('txtProjectId');?>" />
    </div>
</div>
<div class="divRow">
    <div class="divColumn">
    Project Name:
    </div>
    <div class="divColumn">
    <input type="text" name="txtProjectName" id="txtProjectName" 
    value="<?php if(validation_errors()) echo set_value('txtProjectName');?>" />
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Select:</div>
    <div class="divColumn50">
    <input type="radio" name="radbtnPrivate" value="0"  />Private
    <input type="radio" name="radbtnPrivate" value="1"/>Government
    <input type="radio" name="radbtnPrivate" value="2"/>Personal
    </div>
</div>

<div class="divRow">
<div class="divColumn">
    Department:
        </div>
            <div class="divColumn">
                <select name="lst_dept" multiple="">  
                  <?php foreach($query_dept as $dept) { ?>                                                                        
                    <option value="<?php echo $dept->id_num; ?>"><?php echo $dept->dept_name;?></option>
                   <?php } ?>                                                  
                    </select>
            </div>
</div>  

<div class="divRow">              
<div class="divColumn">In Charge:</div>
    <div class="divColumn">
    <input type="text" name="txtInCharge" id="txtInCharge"
     value="<?php if(validation_errors()) echo set_value('txtInCharge'); ?>" />
    </div>
</div>

<div class="divRow">
<div class="divColumn">Status:</div>
    <div class="divColumn">
    <textarea name="txtStatus" rows="4" cols="50"><?php if(validation_errors()) echo set_value('txtStatus'); ?></textarea>
    </div>
</div>

<div class="divRow">
<div class="divColumn">Customer:</div>
            <div class="divColumn">
                <select name="lst_customer" multiple="">
                <?php foreach($query_custname as $custname) { ?>                                                                            
                    <option value="<?php echo $custname->id_num;?>"><?php echo $custname->last_n; ?></option>
                    <?php } ?>                                                  
                    </select>
            </div>

</div>

<div class="divRow">
<div class="divColumn">Company:</div>
                <div class="divColumn">
                <select name="lst_company" multiple="">
                <?php foreach($query_comp as $comp){ ?>                                                                            
                    <option value="<?php echo $comp->id_num;?>"><?php echo $comp->company_name;?></option>
                    <?php } ?>                                                  
                    </select>
                </div>
</div>

<div class="divRow">
<div class="divColumn">Payment Details:</div>
    <div class="divColumn">
    <textarea name="txtPayment_details" rows="4" cols="50"><?php if(validation_errors()) echo set_value('txtPayment_status'); ?></textarea>
    </div>
</div>

<div class="divRow">
<div class="divColumn">Assigned Employee:</div>
                <div class="divColumn">
                <select name="lst_assigned" multiple="multiple" >
                <?php foreach($query_assigned as $assigned) { ?> 
                    <option value="<?php echo $assigned->id_num; ?>"><?php echo $assigned->lname;?></option>
                    <?php } ?>
                    </select>
                </div>
</div>

<div class="divRow">
<div class="divColumn">Polisher/Finisher:</div>
        <div class="divColumn">
        <input type="text" name="txtPolisher" id="txtPolisher"
        value="<?php if(validation_errors()) echo set_value('txtPolisher'); ?>"  />
        </div>
</div>

<div class="divRow">
<div class="divColumn">Delivery:</div>
        <div class="divColumn">
        <input type="text" name="txtDeliver" id="txtDeliver"
        value="<?php if(validation_errors()) echo set_value('txtDeliver');?>" />
        </div>
</div>

<div class="divRow">
<div class="divColumn">Contract Amount:</div>
        <div class="divColumn">
        <input type="text" name="txtContractAmount" id="txtContractAmount"
        value="<?php if(validation_errors()) echo set_value('txtContactAmount'); ?>" />
        </div>
</div>

<div class="divRow">
<div class="divColumn">Delivery Schedule:</div>
        <div class="divColumn">
        <input type="text" name="txtDeliverySched" id="txtDeliverySched"
        value="<?php if(validation_errors()) echo set_value('txtDeliverySched'); ?>"  />
        </div>
</div>

<div class="divRow">
<div class="divColumn">Warranty:</div>
        <div class="divColumn">
        <input type="text" name="txtWarranty" id="txtWarranty"
        value="<?php if(validation_errors()) echo set_value('txtWarranty'); ?>" />
        </div>
</div>

<div class="divRow">
<div class="divColumn">Supplier:</div>
        <div class="divColumn">
        <input type="text" name="txtSupplier" id="txtSupplier"
        value="<?php if(validation_errors()) echo set_value('txtSupplier'); ?>" />
        </div>
</div>

<div class="divRow">
<div class="divColumn">Attachments:</div>
        <div class="divColumn">
        <input type="text" name="txtAttachments" id="txtAttachments"
        value="<?php if(validation_errors()) echo set_value('txtAttachments'); ?>" />
        </div>
</div>
</div>


<div class="divRow">
    <div class="divColumn">
    <input type="button" name="btnViewAttachments"  value="View Attachments" />
    </div>    
    <div class="divColumn">
    <input type="button" name="btnAddAttachments"  value="Add Attachments" />
    </div>
    <div class="divColumn">
    <input type="button" name="btnDeleteAttachments"  value="Delete Attachments" />
    </div>
    <div class="divColumn">
    <input type="button" name="btnAdd"  value="Add" />
    </div>
    <div class="divColumn">
    <input type="button" name="btnEdit"  value="Edit" />
    </div>
    <div class="divRow">
    <input type="submit" value="Save" />
    </div>
    <div class="divRow">
    <input type="button" name="btnDelete"  value="Delete" />  
    </div>
</div>                                       
<?php echo form_close(); ?>