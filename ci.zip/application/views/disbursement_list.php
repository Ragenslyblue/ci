Disbursement List
<div class="divTable">
<div class="containerDiv">

  <div class="rowDivHeader">
    <div class="cellDivHeader">Department</div>
    <div class="cellDivHeader">#</div>
    <div class="cellDivHeader">Particulars</div>
    <div class="cellDivHeader">Project</div>
    <div class="cellDivHeader">Expenses</div>
    <div class="cellDivHeader">Include</div>
    <div class="cellDivHeader lastCell">Amount</div>
  </div>

  <div class="rowDiv">
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv lastCell"></div>
  </div>
</div>
</div>