<?php $this->load->helper('form');
$this->load->library('form_validation');
echo "<span class='errmsg'>".validation_errors()."</span>";
echo form_open_multipart('ProductList_Controller/processInfo');
echo "<span class='errmsg'>".$errMsg."</span>";
 

?>
<div class="divTable">
<div class="divRow">
<div class="divColumn">Product ID:</div>
    <div class="divColumn">
    <input type="text" name="txtProductId" 
    value="<?php echo $product_id; if(validation_errors()) echo set_value('txtProductId'); ?>" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Product Name:</div>
    <div class="divColumn">
    <input type="text" name="txtProductName"
    value="<?php if(validation_errors()) echo set_value('txtProductName'); ?>"  />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Materials:</div>
    <div class="divColumn">
    <input type="text" name="txtMaterials"
    value="<?php if(validation_errors()) echo set_value('txtMaterials'); ?>" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Size:</div>
    <div class="divColumn">
    <input type="text" name="txtSize"
    value="<?php if(validation_errors()) echo set_value('txtSize'); ?>" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Color:</div>
    <div class="divColumn">
    <input type="text" name="txtColor"
    value="<?php if(validation_errors()) echo set_value('txtColor'); ?>"/>
    </div>
</div>
<div class="divRow">
<div class="divColumn">Other Info:</div>
    <div class="divColumn">
    <textarea name="txtOther" rows="10" cols="50"><?php if(validation_errors()) echo set_value('txtOther'); ?></textarea>
    </div>
</div>
<div class="divRow">
<div class="divColumn">Project:</div>
    <div class="divColumn">
    <select name="lst_proj" multiple="">
        <?php foreach ($query_proj as $proj) { ?>
        <option value="<?php echo $proj->project_id?>"><?php echo $proj->project_name;?></option>
        <?php } ?>
</select>
    </div>
</div>
<div class="divRow">
<div class="divColumn">Department:</div>
    <div class="divColumn">
    <select name="lst_dept" multiple="">
        <?php foreach ($query_dept as $dept){?>
        <option value="<?php echo $dept->id_num;?>"><?php echo $dept->dept_name; ?></option>
        <?php } ?>
</select>
    </div>
</div>
<div class="divRow">
<div class="divColumn">Unit Price:</div>
    <div class="divColumn">
    <input type="text" name="txtUnitPrice"
    value="<?php if(validation_errors()) echo set_value('txtUnitPrice'); ?>"/>
    </div>
</div>
<div class="divRow">
<div class="divColumn">Unit Used:</div>
    <div class="divColumn">
    <select name="lst_unit" multiple="">
        <?php foreach($query_unit as $unit){ ?>
        <option value="<?php echo $unit->id_num; ?>"><?php echo $unit->unit_used; ?></option>
        <?php } ?>
</select>
    </div>
</div>
<div class="divRow">
<div class="divColumn">Product Code:</div>
    <div class="divColumn">
    <input type="text" name="txtProductCode"
    value="<?php if(validation_errors()) echo set_value('txtProductCode'); ?>"/>
    </div>
</div>
<div class="divRow">
<div class="divColumn">Model:</div>
    <div class="divColumn">
    <input type="text" name="txtModel"
    value="<?php if(validation_errors()) echo set_value('txtModel'); ?>" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Serial-no.:</div>
    <div class="divColumn">
    <input type="text" name="txtSerialNum"
    value="<?php if(validation_errors()) echo set_value('txtSerialNum'); ?>"/>
    </div>
</div>
<div class="divRow">
<div class="divColumn">Weight:</div>
    <div class="divColumn">
    <input type="text" name="txtWeight"
    value="<?php if(validation_errors()) echo set_value('txtWeight'); ?>" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Length:</div>
    <div class="divColumn">
    <input type="text" name="txtLength"
    value="<?php if(validation_errors()) echo set_value('txtLength'); ?>" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Height:</div>
    <div class="divColumn">
    <input type="text" name="txtHeight"
    value="<?php if(validation_errors()) echo set_value('txtHeight'); ?>" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Width/Depth:</div>
    <div class="divColumn">
    <input type="text" name="txtWidthDepth"
    value="<?php if(validation_errors()) echo set_value('txtWidthDepth'); ?>"/>
    </div>
</div>
<div class="divRow">
<div class="divColumn">Design:</div>
    <div class="divColumn">
    <input type="text" name="txtDesign"
    value="<?php if(validation_errors()) echo set_value('txtDesign'); ?>" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Warranty:</div>
    <div class="divColumn">
    <input type="text" name="txtWarranty"
    value="<?php if(validation_errors()) echo set_value('txtWarranty'); ?>" />
    </div>
</div>
<div class="divRow">

<div class="divColumn">Supplier:</div>
    <div class="divColumn">
    <input type="text" name="txtSupplier"
    value="<?php if(validation_errors()) echo set_value('txtSupplier'); ?>" />
    </div>
</div>
</div>
<div class="divRow">
    <div class="divRow">
    <input type="file" name="btnImage"  />
    </div>
    <div class="divRow">
    <input type="button" name="btnAdd"  value="Add" />   
    </div> 
    <div class="divRow">
    <input type="button" name="btnEdit" value="Edit" />
    </div>
    <div class="divRow">
    <input type="submit" value="Save" />
    </div>
    <div class="divRow">
    <input type="submit" value="Delete"/>
    </div>
</div>
</form>