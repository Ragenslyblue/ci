<form action="" name="form_customer_account" enctype="multipart/form-data">
<div class="divTable">
<div class="divRow">
    <div class="divColumn">
    Customer Account
    </div>
</div>
<div class="divRow">
    <div class="divColumn">
    Customer ID:
    </div>
    <div class="divColumn">
    <input type="text" name="txtCustomerID" class="txtCustomerID" />
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Account ID:</div>
    <div class="divColumn">
    <input type="text" name="txtAccountID" class="txtAccountID" />
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Name:</div>
    <div class="divColumn">
    <input type="text" name="txtName" class="txtName" />
    </div>
    <div class="divColumn">
    <input type="text" name="txtSurname" class="txtSurname" />
    </div>
    <div class="divColumn">
    <input type="text" name="txtMiddleName" class="txtMiddleName" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Payment Term:</div>
            <div class="divColumn">
            <select>                                                                            
                    <option value="Joh"></option>                                                  
                    <option value="Do"></option>                                                   
                    <option value="Wann"></option>
                    </select>
            </div>
            <div class="divColumn">
           <select>                                                                            
                    <option value="Joh1">3</option>                                                  
                    <option value="Do1"></option>                                                   
                    <option value="Wann1"></option>
                    </select>
           </div>
           <div class="divColumn">
           <select>                                                                            
                    <option value="Joh2">mos.</option>                                                  
                    <option value="Do2"></option>                                                   
                    <option value="Wann2"></option>
                    </select>
           </div>
</div>
<div class="divRow">           
    <div class="divColumn">Interest:</div>
    <div class="divColumn">
    <input type="text" name="txtInterest" />
    </div>
    <div>% mo.</div>
</div>
<div class="divRow">
<div class="divColumn">Disbursement List</div>
<div class="containerDiv">

  <div class="rowDivHeader">
    <div class="cellDivHeader">#</div>
    <span></span>
    <div class="cellDivHeader">Date of Transaction</div>
    <input type="text" name="txtDateOfTransact" />
    <div class="cellDivHeader">Particulars/Product</div>
    <input type="text" name="txtParticulars" />
    <div class="cellDivHeader">Charges</div>
    <input type="text" name="txtCharges" />
    <div class="cellDivHeader">Payment</div>
    <input type="text" name="txtPayment" />
    <div class="cellDivHeader">O/S Balance</div>
    <input type="text" name="txtOsBalance" />
  </div>
</div>

  <div class="rowDiv">
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv"></div>
    <div class="cellDiv lastCell"></div>
  </div>
</div>
</div>

<div class="divRow">
    <div class="divRow">
    <input type="button" name="btnAdd" value="Add" />
    </div>
    <div class="divRow">
    <input type="button" name="btnEdit" value="Edit" />
    </div>
    <div class="divRow">
    <input type="button" name="btnDelete" value="Delete" />
    </div>
</div>
</form>