<?php $this->load->helper('form');
$this->load->library('form_validation'); 
echo "<span class='errmsg'>**** lacking file upload ********</span>";
echo "<span class='errmsg'>".validation_errors()."</span>"; 

echo form_open_multipart('Customerinfo_Controller/processInfo'); 
echo "<span class='errmsg'>".$errMsg."</span>";
?>
<div class="divTable">
<div class="divRow">
    <div class="divColumn50"><h2>CUSTOMER INFORMATION</h2></div>
</div>
<div class="divRow">
    <div class="divColumn">Customer ID:</div>
    <div class="divColumn50">
    <input type="text" name="txtid" id="txtid" 
        value="<?php echo $curr_id; if(validation_errors()) echo set_value('txtid'); ?>" />
    <input type="submit" name="btnView" id="btnView" value="View" />
    </div>
    
</div>
<div class="divRow">
<div class="divColumn">Lastname:</div>
    <div class="divColumn50">
    <input type="text" name="txtlast" id="txtlast" 
        value="<?php if(validation_errors()) echo set_value('txtlast'); ?>" />
    </div>
    
</div>
<div class="divRow">
    <div class="divColumn">Firstname:</div>
    <div class="divColumn50">
    <input type="text" name="txtfirst" id="txtfirst" 
        value="<?php if(validation_errors()) echo set_value('txtfirst'); ?>" />
    </div>
</div>
<div class="divRow">
<div class="divColumn">Middlename:</div>
    <div class="divColumn50">
    <input type="text" name="txtmiddle" id="txtmiddle" 
        value="<?php if(validation_errors()) echo set_value('txtmiddle'); ?>" />
    </div>
    
</div>
<div class="divRow">
<div class="divColumn">Age:</div>
    <div class="divColumn50">
    <input type="text" name="txtage" id="txtage" 
        value="<?php if(validation_errors()) echo set_value('txtage'); ?>" />
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Gender:</div>
    <div class="divColumn50">
    <input type="radio" name="radbtnGender" value="0"  />Male
    <input type="radio" name="radbtnGender" value="1"/>Female
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Civil Status:</div>
    <div class="divColumn50">
    <input type="radio" name="radBtnStatus" value="0" />Single
    <input type="radio" name="radBtnStatus" value="1" />Married
    <input type="radio" name="radBtnStatus" value="2"/>Widow
    <input type="radio" name="radBtnStatus" value="3" />Separated
    <input type="radio" name="radBtnStatus" value="4" />Living-In
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Present address:</div>
    <div class="divColumn50">
    <textarea name="txtPresentAdd" rows="2" cols="40"><?php if(validation_errors()) echo set_value('txtPresentAdd'); ?></textarea>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Residential Status:</div>
    <div class="divColumn50">
    <input type="radio" name="radbtnResStat" value="0" />Rent
    <input type="radio" name="radbtnResStat" value="1"/>Owned
    <input type="text" name="txtLenResidence"  /> # of months
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Permanent address:</div>
    <div class="divColumn50">
     <textarea name="txtpermanent" rows="2" cols="40" ><?php if(validation_errors()) echo set_value('txtpermanent'); ?></textarea>
     </div>
</div>
<div class="divRow">
    <div class="divColumn">Home Phone #:</div>
    <div class="divColumn50">
    <input type="text" name="txtContactHome" id="txtContactHome"
     value="<?php if(validation_errors()) echo set_value('txtContactHome'); ?>" />
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Office Phone #:</div>
    <div class="divColumn50">
    <input type="text" name="txtContactOffice" id="txtContactOffice" 
    value="<?php if(validation_errors()) echo set_value('txtContactOffice'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Cell Phone #:</div>
    <div class="divColumn50">
    <input type="text" name="txtContactCell" id="txtContactCell" 
    value="<?php if(validation_errors()) echo set_value('txtContactCell'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Email Address:</div>
    <div class="divColumn50">
    <input type="text" name="txtEmail" id="txtEmail" 
    value="<?php if(validation_errors()) echo set_value('txtEmail'); ?>"/>
    </div>
</div>
</div>
<br />
<br />
<hr />
<br />
<div class="divTable">
<div class="divRow">
    <div class="divColumn50"><h2>EMPLOYMENT INFORMATION</h2></div>
</div>
<div class="divRow">
    <div class="divColumn">Source of Income</div>
    <div class="divColumn50">
    <input type="radio" name="radbtnIncome" value="0" />Salary
    <input type="radio" name="radbtnIncome" value="1" />Business
    <input type="radio" name="radbtnIncome" value="2" />Pension
    <input type="radio" name="radbtnIncome" value="3" />None
    </div>
</div>
<div class="divRow"> 
    <div class="divColumn">Company Name:</div>
    <div class="divColumn50">
    <input type="text" name="txtCompany" id="txtCompany" 
    value="<?php if(validation_errors()) echo set_value('txtCompany'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Company Address:</div>
    <div class="divColumn50">
    <input type="text" name="txtCompanyAdd" id="txtCompanyAdd" 
    value="<?php if(validation_errors()) echo set_value('txtCompanyAdd'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Position:</div>
    <div class="divColumn50">
    <input type="text" name="txtPosition" id="txtPosition" 
    value="<?php if(validation_errors()) echo set_value('txtPosition'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Monthly Income:</div>
    <div class="divColumn50">
    <input type="text" name="txtIncome" id="txtIncome"
    value="<?php if(validation_errors()) echo set_value('txtIncome'); ?>" />
    </div>
</div>
<div class="divRow">
    <div class="divColumn">
    Employment Status:
    </div>
    <div class="divColumn50">
    <input type="radio" name="radbtnEmpStat" value="0" />Probationary
    <input type="radio" name="radbtnEmpStat" value="1" />Contractual
    <input type="radio" name="radbtnEmpStat" value="2" />Regular
    </div>
</div>
</div>
<br />
<hr />
<br />

<div class="divTable">
<div class="divRow">
    <div class="divColumn">IF MARRIED</div>
</div>
<div class="divRow">
    <div class="divColumn">Spouse name:</div>
    <div class="divColumn50">
    <input type="text" name="txtSpouse" id="txtSpouse" 
    value="<?php if(validation_errors()) echo set_value('txtSpouse'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Age:</div>
    <div class="divColumn50">
    <input type="text" name="txtSpouseAge" id="txtSpouseAge" 
    value="<?php if(validation_errors()) echo set_value('txtSpouseAge'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Contact #:</div>
    <div class="divColumn50">
    <input type="text" name="txtSpouseContact" id="txtSpouseContact" 
    value="<?php if(validation_errors()) echo set_value('txtSpouseContact'); ?>"/>
    </div>
</div>

<div class="divRow">
    <div class="divColumn">Source of Income</div>
    <div class="divColumn50">
    <input type="radio" name="radbtnSpouseIncome" value="0" />Salary
    <input type="radio" name="radbtnSpouseIncome" value="1" />Business
    <input type="radio" name="radbtnSpouseIncome" value="2" />Pension
    <input type="radio" name="radbtnSpouseIncome" value="3" />None
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Company Name:</div>
    <div class="divColumn50">
    <input type="text" name="txtSpouseCompany" id="txtSpouseCompany" 
    value="<?php if(validation_errors()) echo set_value('txtSpouseCompany'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Company Address:</div>
    <div class="divColumn50">
    <input type="text" name="txtSpouseCompanyAdd" id="txtSpouseCompanyAdd"
    value="<?php if(validation_errors()) echo set_value('txtSpouseCompanyAdd'); ?>" />
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Position:</div>
    <div class="divColumn50">
    <input type="text" name="txtSpousePosition" id="txtSpousePosition" 
    value="<?php if(validation_errors()) echo set_value('txtSpousePosition'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Monthly Income:</div>
    <div class="divColumn">
    <input type="text" name="txtSpouseIncome" id="txtSpouseIncome" 
    value="<?php if(validation_errors()) echo set_value('txtSpouseIncome'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">
    Employment Status:
    </div>
    <div class="divColumn50">
    <input type="radio" name="radbtnSpouseEmpStat" value="0" />Probationary
    <input type="radio" name="radbtnSpouseEmpStat" value="1" />Contractual
    <input type="radio" name="radbtnSpouseEmpStat" value="2" />Regular
    </div>
</div>
<div class="divRow">
    <div class="divColumn">Number of Children:</div>
    <div class="divColumn">
    <input type="text"  name="txtNumChild" id="txtNumChild" 
    value="<?php if(validation_errors()) echo set_value('txtNumChild'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">&nbsp;</div>                                                          
    <div class="divColumn">Name of Child</div>
    <div class="divColumn">Educational Attainment</div>
</div>
<div class="divRow">
    <div class="divColumn">&nbsp;</div>
    <div class="divColumn">
    <input type="text" name="txtChild1" id="txtChild1" 
    value="<?php if(validation_errors()) echo set_value('txtChild1'); ?>"/>
    </div>
    <div class="divColumn">
    <input type="text" name="txtEduc1" id="txtEduc1" 
    value="<?php if(validation_errors()) echo set_value('txtEduc1'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">&nbsp;</div>
    <div class="divColumn">
    <input type="text" name="txtChild2" id="txtChild2" 
    value="<?php if(validation_errors()) echo set_value('txtChild2'); ?>"/>
    </div>
    <div class="divColumn">
    <input type="text" name="txtEduc2" id="txtEduc2" 
    value="<?php if(validation_errors()) echo set_value('txtEduc2'); ?>"/>
    </div>
</div>
<div class="divRow">
    <div class="divColumn">&nbsp;</div>
    <div class="divColumn">
    <input type="text" name="txtChild3" id="txtChild3" 
    value="<?php if(validation_errors()) echo set_value('txtChild3'); ?>"/>
    </div>
    <div class="divColumn">
    <input type="text" name="txtEduc3" id="txtEduc3"
    value="<?php if(validation_errors()) echo set_value('txtEduc3'); ?>" />
    </div>
</div>
<div class="divRow">
<span><img class="image" /></span>
    <div class="divColumn">
    Upload Image
    <input type="file" name="fileImage" id="fileImage" />
    </div>
    <div class="divColumn">
    Upload Sketch
    <input type="file" name="fileSketch" id="fileSketch" />
    </div>
</div>
<div class="divRow">
    <div class="divColumn">&nbsp;</div>
    <div class="divColumn50">
    
    <input type="submit" name="btnSave" id="btnSave" value="Save" />    
    <input type="submit" name="btnEdit" id="btnEdit" value="Edit" />
    </div>
</div>
</div>
<?php echo form_close();?>