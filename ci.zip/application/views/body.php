	<h1>Welcome to CodeIgniter!</h1>

	<div id="body">
		<p>THIS THE BODY
</p>
</div>
