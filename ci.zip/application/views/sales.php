<form action="<?php echo $BASE_URL;?>index.php?page=save_sales">
<div>Daily Sales</div><div>Weekly</div><div>Monthly</div><div>Quarterly</div><div>Yearly</div>
Date:<input type="text" name="txtDate" class="txtDate" /><br />
Cash Sales:<input type="text" name="txtCashSales" class="txtCashSales" /><br />
Collections:<input type="text" name="txtCollections" class="txtCollections" /><br />
Total Daily Sales:<input type="text" name="txtDailySales" class="txtDailySales" /><br />
Less: Rebate:<input type="text" name="txtLessRebate" class="txtLessRebate" /><br />
        Discount:<input type="text" name="txtDiscout" class="txtDiscout" /><br />
Net Sales:<input type="text" name="txtNetSales" class="txtNetSales" /><br />
Less: Disbursement:<input type="text" name="txtLessDisbursement" class="txtLessDisbursement" /><br />
Net Sales(After Expenses):<input type="text" name="txtNetAfterExpenses" class="txtNetAfterExpenses"  /><br />
<input type="submit" value="View SalesList" /><input type="submit" value="View Disbursement" /><input type="submit" value="Print Report" />
</form>