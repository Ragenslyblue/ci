-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2015 at 03:31 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gallega_marketing`
--

-- --------------------------------------------------------

--
-- Table structure for table `customerid_startpoint`
--

CREATE TABLE IF NOT EXISTS `customerid_startpoint` (
`id_num` int(11) NOT NULL,
  `starting_point` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `customerid_startpoint`
--

INSERT INTO `customerid_startpoint` (`id_num`, `starting_point`) VALUES
(3, 1800);

-- --------------------------------------------------------

--
-- Table structure for table `customer_account`
--

CREATE TABLE IF NOT EXISTS `customer_account` (
`id_num` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `customer_info`
--

CREATE TABLE IF NOT EXISTS `customer_info` (
`id_num` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `first_n` varchar(100) NOT NULL,
  `middle_n` varchar(100) NOT NULL,
  `last_n` varchar(100) NOT NULL,
  `age` int(10) NOT NULL,
  `present_address` varchar(100) NOT NULL,
  `permanent_address` varchar(100) NOT NULL,
  `sex` int(1) NOT NULL COMMENT '0=male, 1=female',
  `civil_status` int(1) NOT NULL COMMENT '0=single, 1=married, 2=widow, 3=separated, 4=living-in',
  `image_url` varchar(100) DEFAULT NULL,
  `sketch_url` varchar(100) DEFAULT NULL,
  `residential_status` int(1) NOT NULL COMMENT '0=rent, 1=owned',
  `length_residence_mos` int(5) NOT NULL COMMENT 'length of residence in months',
  `source_income` int(1) NOT NULL COMMENT '0=salary, 1=business, 2=pension, 3=none',
  `company_name` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `company_address` varchar(100) NOT NULL,
  `mo_income` decimal(10,0) NOT NULL,
  `employment_status` int(1) NOT NULL COMMENT '0=probationary, 1=contractual, 2=regular',
  `contact_home` varchar(50) NOT NULL,
  `contact_office` varchar(50) NOT NULL,
  `cellphone` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `customer_info`
--

INSERT INTO `customer_info` (`id_num`, `customer_id`, `first_n`, `middle_n`, `last_n`, `age`, `present_address`, `permanent_address`, `sex`, `civil_status`, `image_url`, `sketch_url`, `residential_status`, `length_residence_mos`, `source_income`, `company_name`, `position`, `company_address`, `mo_income`, `employment_status`, `contact_home`, `contact_office`, `cellphone`, `email`) VALUES
(43, 151800, 'c', 'j', 'gallega', 28, 'address', 'permanent', 1, 0, '', '', 1, 0, 0, 'gm', 'cas', 'comp', '123456', 2, '123', '2334', '345', 'adsfa@ya.co'),
(44, 151801, 'cde', 'fgh', 'abc', 44, 'present', 'permanent', 0, 1, 'Desert.jpg', 'Penguins.jpg', 1, 33, 0, 'companbyt', 'my position', 'companyt address', '90000', 1, '7454', '222222', '4444444', 'adaf@ya.ck'),
(45, 151802, 'fsfsfs', 'fdsdfs', 'sdfsafsfs', 1212, 'ewqewq', 'qeqwwqe', 1, 1, 'Lighthouse.jpg', 'Penguins.jpg', 1, 1211, 1, 'zxczxc', 'zczczxc', 'zxczxczc', '232', 0, '12', '222', '1222', 'weaeqw2@kjhk.com'),
(46, 151803, 'www', 'weee', 'sfsasa', 333, 'ssss', 'sadsad', 1, 1, '', '', 1, 2, 1, 'sdfsdf', 'sdfsdf', 'fdsfds', '33', 0, '11111', '22221', '3333', 'dad2@ya.cjf'),
(49, 151804, 'd', 'd', 'sdfsafsfs', 0, '', '', 0, 1, '', '', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(50, 151805, '', '', 'dffffff', 0, '', '', 0, 1, '', '', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(51, 151806, 'sdfsdf', 'sdfdsf', 'fsfsf', 3333, 'ssss', 'ssssssssssss', 1, 1, '', '', 1, 0, 1, 'sfdsafss', 'sdfsf', 'fsdfsd', '22222', 1, '11111', '22', '23', 'sdsd@sfas.com'),
(52, 151807, '', '', '', 0, '', '', 0, 0, 'Tulips.jpg', '', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(53, 151808, '', '', 'ddddd', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(54, 151809, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(55, 151810, '', '', '', 0, '', '', 0, 1, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(56, 151811, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(57, 151812, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(58, 151813, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(59, 151814, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(60, 151815, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(61, 151816, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(62, 151817, '', '', 'mjhjj', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(63, 151818, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(64, 151819, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, 'xczxczx', '', '', '0', 0, '', '', '', ''),
(65, 151820, '', '', '', 0, '', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', ''),
(66, 151821, 'hghjg', 'kjhkjh', 'jkhjkh', 14, 'JLKKL', '', 0, 0, '0', '0', 0, 0, 0, 'jhjhgj', '', '', '0', 0, '', '', '', ''),
(67, 151822, 'hjgjh', 'khlkjhl', 'jhjkh', 8, 'hjklhj', '', 0, 0, '0', '0', 0, 0, 0, '', '', '', '0', 0, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `customer_spouse`
--

CREATE TABLE IF NOT EXISTS `customer_spouse` (
`id_num` int(11) NOT NULL,
  `customer_info_id` varchar(11) NOT NULL,
  `spouse_name` varchar(100) NOT NULL,
  `age` int(10) NOT NULL,
  `contact` int(11) NOT NULL,
  `source_income` int(1) NOT NULL COMMENT '0=salary, 1=business, 2=pension, 3=none',
  `company_name` varchar(100) NOT NULL,
  `company_address` varchar(100) NOT NULL,
  `mo_income` decimal(10,0) NOT NULL,
  `employment_status` int(1) NOT NULL COMMENT '0=probationary, 1=contractual, 2=regular',
  `number_children` int(10) NOT NULL,
  `position` varchar(100) NOT NULL,
  `child1` varchar(50) NOT NULL,
  `child2` varchar(50) NOT NULL,
  `child3` varchar(50) NOT NULL,
  `educ1` varchar(50) NOT NULL,
  `educ2` varchar(50) NOT NULL,
  `educ3` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `customer_spouse`
--

INSERT INTO `customer_spouse` (`id_num`, `customer_info_id`, `spouse_name`, `age`, `contact`, `source_income`, `company_name`, `company_address`, `mo_income`, `employment_status`, `number_children`, `position`, `child1`, `child2`, `child3`, `educ1`, `educ2`, `educ3`) VALUES
(11, '151806', 'aaaaaaa', 222, 111, 1, 'saasdas', 'fsa', '11111', 0, 3, 'faa', 'ddd', 'aaas', 'ssss', 'aa', 'ddd', 'eeee'),
(12, '151810', 'bxbxxvb', 0, 0, 0, '', '', '0', 0, 0, '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE IF NOT EXISTS `department` (
`id_num` int(11) NOT NULL,
  `dept_name` varchar(100) NOT NULL,
  `date_entered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id_num`, `dept_name`, `date_entered`) VALUES
(19, 'Furniture', '2015-03-12 00:29:04'),
(20, 'Glass', '2015-03-12 00:29:12'),
(21, 'Steel', '2015-03-12 00:29:18'),
(24, 'department', '2015-06-23 15:50:30'),
(25, 'civil engineer office', '2015-06-23 15:50:50'),
(26, 'unit price', '2015-06-29 17:04:56'),
(27, 'accounting', '2015-06-29 17:05:11');

-- --------------------------------------------------------

--
-- Table structure for table `disbursement`
--

CREATE TABLE IF NOT EXISTS `disbursement` (
`id_num` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `particulars` varchar(100) NOT NULL,
  `project_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `payment_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `attachment_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
`id_num` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `date_hired` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nick` varchar(50) NOT NULL,
  `age` int(2) NOT NULL,
  `present_add` varchar(200) NOT NULL,
  `permanent_add` varchar(200) NOT NULL,
  `gender` int(1) NOT NULL COMMENT '0=male, 1=female',
  `marital_stat` int(1) NOT NULL COMMENT '0=single, 1=married, 2=widow, 3=separated, 4=living-in',
  `contact1` int(11) NOT NULL,
  `contact2` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `attachment1` varchar(50) NOT NULL,
  `attachment2` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `payment_term`
--

CREATE TABLE IF NOT EXISTS `payment_term` (
`id_num` int(11) NOT NULL,
  `payment_type_id` int(10) NOT NULL,
  `term` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `payment_term`
--

INSERT INTO `payment_term` (`id_num`, `payment_type_id`, `term`) VALUES
(1, 1, 'asdselect'),
(2, 15, '6select'),
(5, 23, '6-months'),
(9, 24, '15-days'),
(10, 24, '30-days'),
(14, 23, '2-months'),
(15, 28, 'cash=5-months');

-- --------------------------------------------------------

--
-- Table structure for table `payment_type`
--

CREATE TABLE IF NOT EXISTS `payment_type` (
`id_num` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `date_entered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `payment_type`
--

INSERT INTO `payment_type` (`id_num`, `payment_type`, `date_entered`) VALUES
(23, 'Installment', '2015-03-14 05:54:36'),
(26, 'Spot Cash', '2015-03-14 05:55:25'),
(27, 'cheque', '2015-03-18 05:16:25'),
(28, 'cash', '2015-06-11 17:47:14');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
`id_num` int(10) NOT NULL,
  `item_id` int(10) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `material` varchar(100) NOT NULL,
  `size` int(10) NOT NULL,
  `color` varchar(100) NOT NULL,
  `other_info` varchar(100) NOT NULL,
  `image` varchar(200) DEFAULT NULL,
  `department_id` int(10) NOT NULL,
  `project_id` int(10) NOT NULL,
  `unit_price` int(10) NOT NULL,
  `unit_used` datetime NOT NULL,
  `product_code` int(10) NOT NULL,
  `model` varchar(100) NOT NULL,
  `serial` int(10) NOT NULL,
  `weight` int(10) NOT NULL,
  `length` int(10) NOT NULL,
  `height` int(10) NOT NULL,
  `depth/width` int(10) NOT NULL,
  `design` varchar(100) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `productid_startpoint`
--

CREATE TABLE IF NOT EXISTS `productid_startpoint` (
`id_num` int(11) NOT NULL,
  `starting_point` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `projectid_startpoint`
--

CREATE TABLE IF NOT EXISTS `projectid_startpoint` (
`id_num` int(11) NOT NULL,
  `starting_point` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `projectid_startpoint`
--

INSERT INTO `projectid_startpoint` (`id_num`, `starting_point`) VALUES
(2, 1000);

-- --------------------------------------------------------

--
-- Table structure for table `project_details`
--

CREATE TABLE IF NOT EXISTS `project_details` (
`id_num` int(11) NOT NULL,
  `projectlist_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `project_details`
--

INSERT INTO `project_details` (`id_num`, `projectlist_id`, `department_id`, `employee_id`) VALUES
(1, 0, 0, 0),
(2, 0, 0, 0),
(3, 0, 0, 0),
(4, 0, 0, 0),
(5, 0, 0, 0),
(6, 0, 0, 0),
(7, 0, 0, 0),
(8, 151000, 0, 0),
(9, 151000, 0, 0),
(10, 151000, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `project_list`
--

CREATE TABLE IF NOT EXISTS `project_list` (
`id_num` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `project_name` varchar(100) NOT NULL,
  `amount` int(11) NOT NULL,
  `private_govt` varchar(100) NOT NULL COMMENT '0=private; 1=govt; 2=personal',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `payment_details` varchar(255) NOT NULL,
  `polisher` varchar(100) NOT NULL,
  `warranty` int(10) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `delivery` varchar(100) NOT NULL,
  `contract_amount` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `receipt_details`
--

CREATE TABLE IF NOT EXISTS `receipt_details` (
`id_num` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `customer_id` int(11) NOT NULL,
  `unit_type` varchar(100) NOT NULL,
  `receipt_num` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `attachment_id` int(11) NOT NULL,
  `rebate` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `item_id` int(11) NOT NULL,
  `receipt_type` varchar(100) NOT NULL,
  `gross_sales` int(10) NOT NULL,
  `vat` int(10) NOT NULL,
  `reg_discount` int(10) NOT NULL,
  `pwd_discount` int(10) NOT NULL,
  `net_sales` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `receipt_series`
--

CREATE TABLE IF NOT EXISTS `receipt_series` (
`id_num` int(10) NOT NULL,
  `receipt_type_id` int(10) NOT NULL,
  `series_num_from` int(10) NOT NULL,
  `series_num_to` int(10) NOT NULL,
  `in_use` int(1) NOT NULL DEFAULT '0' COMMENT '0 for no, 1 for yes'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `receipt_series`
--

INSERT INTO `receipt_series` (`id_num`, `receipt_type_id`, `series_num_from`, `series_num_to`, `in_use`) VALUES
(1, 17, 100, 150, 0);

-- --------------------------------------------------------

--
-- Table structure for table `receipt_type`
--

CREATE TABLE IF NOT EXISTS `receipt_type` (
`id_num` int(10) NOT NULL,
  `receipt_type` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `receipt_type`
--

INSERT INTO `receipt_type` (`id_num`, `receipt_type`) VALUES
(17, 'Delivery Receipt'),
(18, 'Temporary Delivery Receipt'),
(20, 'Charge Invoice'),
(21, 'Official Receipt'),
(22, 'cash');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customerid_startpoint`
--
ALTER TABLE `customerid_startpoint`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `customer_account`
--
ALTER TABLE `customer_account`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `customer_info`
--
ALTER TABLE `customer_info`
 ADD PRIMARY KEY (`id_num`), ADD UNIQUE KEY `cust_id` (`customer_id`);

--
-- Indexes for table `customer_spouse`
--
ALTER TABLE `customer_spouse`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
 ADD PRIMARY KEY (`id_num`), ADD UNIQUE KEY `dept_name` (`dept_name`);

--
-- Indexes for table `disbursement`
--
ALTER TABLE `disbursement`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `payment_term`
--
ALTER TABLE `payment_term`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `payment_type`
--
ALTER TABLE `payment_type`
 ADD PRIMARY KEY (`id_num`), ADD UNIQUE KEY `payment_type` (`payment_type`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `productid_startpoint`
--
ALTER TABLE `productid_startpoint`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `projectid_startpoint`
--
ALTER TABLE `projectid_startpoint`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `project_details`
--
ALTER TABLE `project_details`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `project_list`
--
ALTER TABLE `project_list`
 ADD PRIMARY KEY (`id_num`), ADD UNIQUE KEY `project_id` (`project_id`);

--
-- Indexes for table `receipt_details`
--
ALTER TABLE `receipt_details`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `receipt_series`
--
ALTER TABLE `receipt_series`
 ADD PRIMARY KEY (`id_num`);

--
-- Indexes for table `receipt_type`
--
ALTER TABLE `receipt_type`
 ADD PRIMARY KEY (`id_num`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customerid_startpoint`
--
ALTER TABLE `customerid_startpoint`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `customer_account`
--
ALTER TABLE `customer_account`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customer_info`
--
ALTER TABLE `customer_info`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `customer_spouse`
--
ALTER TABLE `customer_spouse`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `disbursement`
--
ALTER TABLE `disbursement`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payment_term`
--
ALTER TABLE `payment_term`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `payment_type`
--
ALTER TABLE `payment_type`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
MODIFY `id_num` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `productid_startpoint`
--
ALTER TABLE `productid_startpoint`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `projectid_startpoint`
--
ALTER TABLE `projectid_startpoint`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `project_details`
--
ALTER TABLE `project_details`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `project_list`
--
ALTER TABLE `project_list`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `receipt_details`
--
ALTER TABLE `receipt_details`
MODIFY `id_num` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `receipt_series`
--
ALTER TABLE `receipt_series`
MODIFY `id_num` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `receipt_type`
--
ALTER TABLE `receipt_type`
MODIFY `id_num` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
